/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <StepMotor.h>
#include <MotorISR.h>
#include <MotorTimer.h>

void StepMotor_Init()
{
    MotorTimer_Start();
}

void StepMotor_Rotate()
{
    MotorISR_Start();
}

/* [] END OF FILE */
