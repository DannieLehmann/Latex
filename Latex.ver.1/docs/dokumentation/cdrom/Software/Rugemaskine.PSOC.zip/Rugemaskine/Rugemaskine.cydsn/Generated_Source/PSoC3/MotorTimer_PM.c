/*******************************************************************************
* File Name: MotorTimer_PM.c
* Version 2.50
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "MotorTimer.h"
static MotorTimer_backupStruct MotorTimer_backup;


/*******************************************************************************
* Function Name: MotorTimer_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MotorTimer_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void MotorTimer_SaveConfig(void) 
{
    #if (!MotorTimer_UsingFixedFunction)
        /* Backup the UDB non-rentention registers for CY_UDB_V0 */
        #if (CY_UDB_V0)
            MotorTimer_backup.TimerUdb = MotorTimer_ReadCounter();
            MotorTimer_backup.TimerPeriod = MotorTimer_ReadPeriod();
            MotorTimer_backup.InterruptMaskValue = MotorTimer_STATUS_MASK;
            #if (MotorTimer_UsingHWCaptureCounter)
                MotorTimer_backup.TimerCaptureCounter = MotorTimer_ReadCaptureCount();
            #endif /* Backup the UDB non-rentention register capture counter for CY_UDB_V0 */
        #endif /* Backup the UDB non-rentention registers for CY_UDB_V0 */

        #if (CY_UDB_V1)
            MotorTimer_backup.TimerUdb = MotorTimer_ReadCounter();
            MotorTimer_backup.InterruptMaskValue = MotorTimer_STATUS_MASK;
            #if (MotorTimer_UsingHWCaptureCounter)
                MotorTimer_backup.TimerCaptureCounter = MotorTimer_ReadCaptureCount();
            #endif /* Back Up capture counter register  */
        #endif /* Backup non retention registers, interrupt mask and capture counter for CY_UDB_V1 */

        #if(!MotorTimer_ControlRegRemoved)
            MotorTimer_backup.TimerControlRegister = MotorTimer_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: MotorTimer_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MotorTimer_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void MotorTimer_RestoreConfig(void) 
{   
    #if (!MotorTimer_UsingFixedFunction)
        /* Restore the UDB non-rentention registers for CY_UDB_V0 */
        #if (CY_UDB_V0)
            /* Interrupt State Backup for Critical Region*/
            uint8 MotorTimer_interruptState;

            MotorTimer_WriteCounter(MotorTimer_backup.TimerUdb);
            MotorTimer_WritePeriod(MotorTimer_backup.TimerPeriod);
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            MotorTimer_interruptState = CyEnterCriticalSection();
            /* Use the interrupt output of the status register for IRQ output */
            MotorTimer_STATUS_AUX_CTRL |= MotorTimer_STATUS_ACTL_INT_EN_MASK;
            /* Exit Critical Region*/
            CyExitCriticalSection(MotorTimer_interruptState);
            MotorTimer_STATUS_MASK =MotorTimer_backup.InterruptMaskValue;
            #if (MotorTimer_UsingHWCaptureCounter)
                MotorTimer_SetCaptureCount(MotorTimer_backup.TimerCaptureCounter);
            #endif /* Restore the UDB non-rentention register capture counter for CY_UDB_V0 */
        #endif /* Restore the UDB non-rentention registers for CY_UDB_V0 */

        #if (CY_UDB_V1)
            MotorTimer_WriteCounter(MotorTimer_backup.TimerUdb);
            MotorTimer_STATUS_MASK =MotorTimer_backup.InterruptMaskValue;
            #if (MotorTimer_UsingHWCaptureCounter)
                MotorTimer_SetCaptureCount(MotorTimer_backup.TimerCaptureCounter);
            #endif /* Restore Capture counter register*/
        #endif /* Restore up non retention registers, interrupt mask and capture counter for CY_UDB_V1 */

        #if(!MotorTimer_ControlRegRemoved)
            MotorTimer_WriteControlRegister(MotorTimer_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: MotorTimer_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MotorTimer_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void MotorTimer_Sleep(void) 
{
    #if(!MotorTimer_ControlRegRemoved)
        /* Save Counter's enable state */
        if(MotorTimer_CTRL_ENABLE == (MotorTimer_CONTROL & MotorTimer_CTRL_ENABLE))
        {
            /* Timer is enabled */
            MotorTimer_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            MotorTimer_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    MotorTimer_Stop();
    MotorTimer_SaveConfig();
}


/*******************************************************************************
* Function Name: MotorTimer_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  MotorTimer_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void MotorTimer_Wakeup(void) 
{
    MotorTimer_RestoreConfig();
    #if(!MotorTimer_ControlRegRemoved)
        if(MotorTimer_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                MotorTimer_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
