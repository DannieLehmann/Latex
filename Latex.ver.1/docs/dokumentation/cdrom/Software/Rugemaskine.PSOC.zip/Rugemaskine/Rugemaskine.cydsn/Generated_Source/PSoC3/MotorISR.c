/*******************************************************************************
* File Name: MotorISR.c  
* Version 1.70
*
*  Description:
*   API for controlling the state of an interrupt.
*
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include <cydevice_trm.h>
#include <CyLib.h>
#include <MotorISR.h>

#if !defined(MotorISR__REMOVED) /* Check for removal by optimization */

/*******************************************************************************
*  Place your includes, defines and code here 
********************************************************************************/
/* `#START MotorISR_intc` */
#include <MotorControlRegister.h>
#include <MotorTimer.h>
static int Direction=1;     //variable defining the Direction of the motor, Default forward
static int Steps_Taken=0;   //Variable defining number of steps taken by the motor
void Step_Forward();        //Forward declaration of the Step_Forward function
void Step_Backward();       //Forward declaration of the Step_Forward function

//////////////////////////
/// Single phase drive ///
//////////////////////////
void Step_Forward()
{
    if(MotorControlRegister_Read() & 0x1)      //Compare 0b0001 -> Set 0b0010
        MotorControlRegister_Write(0x2);       //Setting 0b0010
    else if(MotorControlRegister_Read() & 0x2) //Compare 0b0010 -> Set 0b0100
        MotorControlRegister_Write(0x4);       //Setting 0b0100
    else if(MotorControlRegister_Read() & 0x4) //Compare 0b0100 -> Set 0b1000
        MotorControlRegister_Write(0x8);       //Setting 0b1000
    else if(MotorControlRegister_Read() & 0x8) //Compare 0b1000 -> Set 0b0001
        MotorControlRegister_Write(0x1);       //Setting 0b0001
    MotorTimer_ReadStatusRegister();           //Reset timer interruptflag
}

void Step_Backward()
{
    if(MotorControlRegister_Read() & 0x1)       //Compare 0b0001 -> Set 0b1000
        MotorControlRegister_Write(0x8);        //Setting 0b1000
    else if(MotorControlRegister_Read() & 0x8)  //Compare 0b1000 -> Set 0b0100
        MotorControlRegister_Write(0x4);        //Setting 0b0100
    else if(MotorControlRegister_Read() & 0x4)  //Compare 0b0100 -> Set 0b0010
        MotorControlRegister_Write(0x2);        //Setting 0b0010
    else if(MotorControlRegister_Read() & 0x2)  //Compare 0b0010 -> Set 0b0001
        MotorControlRegister_Write(0x1);        //Setting 0b0001
    MotorTimer_ReadStatusRegister();            //Reset timer interruptflag
}

/* `#END` */


/*******************************************************************************
* Function Name: MotorISR_Start
********************************************************************************
*
* Summary:
*  Set up the interrupt and enable it.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_Start(void) 
{
    /* For all we know the interrupt is active. */
    MotorISR_Disable();

    /* Set the ISR to point to the MotorISR Interrupt. */
    MotorISR_SetVector(&MotorISR_Interrupt);

    /* Set the priority. */
    MotorISR_SetPriority((uint8)MotorISR_INTC_PRIOR_NUMBER);

    /* Enable it. */
    MotorISR_Enable();
}


/*******************************************************************************
* Function Name: MotorISR_StartEx
********************************************************************************
*
* Summary:
*  Set up the interrupt and enable it.
*
* Parameters:  
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_StartEx(cyisraddress address) 
{
    /* For all we know the interrupt is active. */
    MotorISR_Disable();

    /* Set the ISR to point to the MotorISR Interrupt. */
    MotorISR_SetVector(address);

    /* Set the priority. */
    MotorISR_SetPriority((uint8)MotorISR_INTC_PRIOR_NUMBER);

    /* Enable it. */
    MotorISR_Enable();
}


/*******************************************************************************
* Function Name: MotorISR_Stop
********************************************************************************
*
* Summary:
*   Disables and removes the interrupt.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_Stop(void) 
{
    /* Disable this interrupt. */
    MotorISR_Disable();
}


/*******************************************************************************
* Function Name: MotorISR_Interrupt
********************************************************************************
* Summary:
*   The default Interrupt Service Routine for MotorISR.
*
*   Add custom code between the coments to keep the next version of this file
*   from over writting your code.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
CY_ISR(MotorISR_Interrupt)
{
    /*  Place your Interrupt code here. */
    /* `#START MotorISR_Interrupt` */
    if(Direction==1)
    {
        Step_Forward();         //Direction is 1, therefore the forward step is called
        Steps_Taken++;          //Increment the amount of steps taken by the motor
        if(Steps_Taken==1024)   //Check if motor have reached a half circuit
        {
            Direction=2;        //Change direction of the motor to backward
            Steps_Taken=0;      //Reset amount of steps taken
            MotorISR_Disable(); //A half circuit have been completed and the ISR is stopped
        }
    }
    
    else if(Direction==2)
    {
        Step_Backward();        //Direction is 2, therefore the backward step is called
        Steps_Taken++;          //Increment the amount of steps taken by the motor
        if(Steps_Taken==1024)   //Check if motor have reached a half circuit
        {
            Direction=1;        //Change direction of the motor to forward
            Steps_Taken=0;      //Reset amount of steps taken
            MotorISR_Disable(); //A half circuit have been completed and the ISR is stopped
        }
    }
    /* `#END` */

    /* PSoC3 ES1, ES2 RTC ISR PATCH  */ 
    #if(CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3)
        #if((CYDEV_CHIP_REVISION_USED <= CYDEV_CHIP_REVISION_3A_ES2) && (MotorISR__ES2_PATCH ))      
            MotorISR_ISR_PATCH();
        #endif /* CYDEV_CHIP_REVISION_USED */
    #endif /* (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) */
}


/*******************************************************************************
* Function Name: MotorISR_SetVector
********************************************************************************
*
* Summary:
*   Change the ISR vector for the Interrupt. Note calling MotorISR_Start
*   will override any effect this method would have had. To set the vector 
*   before the component has been started use MotorISR_StartEx instead.
*
* Parameters:
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_SetVector(cyisraddress address) 
{
    CY_SET_REG16(MotorISR_INTC_VECTOR, (uint16) address);
}


/*******************************************************************************
* Function Name: MotorISR_GetVector
********************************************************************************
*
* Summary:
*   Gets the "address" of the current ISR vector for the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Address of the ISR in the interrupt vector table.
*
*******************************************************************************/
cyisraddress MotorISR_GetVector(void) 
{
    return (cyisraddress) CY_GET_REG16(MotorISR_INTC_VECTOR);
}


/*******************************************************************************
* Function Name: MotorISR_SetPriority
********************************************************************************
*
* Summary:
*   Sets the Priority of the Interrupt. Note calling MotorISR_Start
*   or MotorISR_StartEx will override any effect this method would 
*   have had. This method should only be called after MotorISR_Start or 
*   MotorISR_StartEx has been called. To set the initial
*   priority for the component use the cydwr file in the tool.
*
* Parameters:
*   priority: Priority of the interrupt. 0 - 7, 0 being the highest.
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_SetPriority(uint8 priority) 
{
    *MotorISR_INTC_PRIOR = priority << 5;
}


/*******************************************************************************
* Function Name: MotorISR_GetPriority
********************************************************************************
*
* Summary:
*   Gets the Priority of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Priority of the interrupt. 0 - 7, 0 being the highest.
*
*******************************************************************************/
uint8 MotorISR_GetPriority(void) 
{
    uint8 priority;


    priority = *MotorISR_INTC_PRIOR >> 5;

    return priority;
}


/*******************************************************************************
* Function Name: MotorISR_Enable
********************************************************************************
*
* Summary:
*   Enables the interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_Enable(void) 
{
    /* Enable the general interrupt. */
    *MotorISR_INTC_SET_EN = MotorISR__INTC_MASK;
}


/*******************************************************************************
* Function Name: MotorISR_GetState
********************************************************************************
*
* Summary:
*   Gets the state (enabled, disabled) of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   1 if enabled, 0 if disabled.
*
*******************************************************************************/
uint8 MotorISR_GetState(void) 
{
    /* Get the state of the general interrupt. */
    return ((*MotorISR_INTC_SET_EN & (uint8)MotorISR__INTC_MASK) != 0u) ? 1u:0u;
}


/*******************************************************************************
* Function Name: MotorISR_Disable
********************************************************************************
*
* Summary:
*   Disables the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_Disable(void) 
{
    /* Disable the general interrupt. */
    *MotorISR_INTC_CLR_EN = MotorISR__INTC_MASK;
}


/*******************************************************************************
* Function Name: MotorISR_SetPending
********************************************************************************
*
* Summary:
*   Causes the Interrupt to enter the pending state, a software method of
*   generating the interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_SetPending(void) 
{
    *MotorISR_INTC_SET_PD = MotorISR__INTC_MASK;
}


/*******************************************************************************
* Function Name: MotorISR_ClearPending
********************************************************************************
*
* Summary:
*   Clears a pending interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void MotorISR_ClearPending(void) 
{
    *MotorISR_INTC_CLR_PD = MotorISR__INTC_MASK;
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
