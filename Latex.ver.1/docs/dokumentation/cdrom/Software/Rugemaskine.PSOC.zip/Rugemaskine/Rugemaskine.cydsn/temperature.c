/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <project.h>
#include <stdio.h>
#include "temperature.h"
#include "HIH61xx.h"
//#include "temp_sensor_dummy.h"

/* PID coefficients */
#define Kp 0.3
#define Ki 1.0
#define Kd 0.0

#define MAX_TEMP 50
#define UPDATE_INTERVAL 5
#define SUCCESS_LIMIT 2
#define ERROR_LIMIT 0
#define TIME_LIMIT 20 //120 //120*5 Sec = 10 minutter

static float setpoint = 0.0, 
            last_error = 0.0,
            integral = 0.0;

static short int errorHandlerTracker = 0,   //Keeps track of recurring successes
            setPointReached = 0,            //Flag for 12 successes in a row
            errorOccured = 0,               //Flag for if error occurred
            timeTracker = 0,                //For timing
            isRunning = 0;

void regulate(float);

float getTemp();

/* For detecting errors; 
 * Will keep track of when the temperature reaches a steady state, within +/- 1 degree of the setpoint
 * for a period of one minute; when this happens, a flag will be set. If the tenperature falls outside this 
 * range more than N times in a row, an error flag is made.
 */

void stabilityControl(float error){
    
    if(setPointReached==0){                            //Until the setpoint is reached...
        if((error*error)<=1){                          //If the error numerically is less than one, add one to the counter
            errorHandlerTracker++;
    
            if(errorHandlerTracker > SUCCESS_LIMIT){   //If we 12 times in a row (a 60 second duration) succesfully stayed within 1 degree, we're have succesfully reached our setpoint
                setPointReached = 1;
                errorHandlerTracker = 0;
                timeTracker = 0;
            }
        }
        
        else {
            errorHandlerTracker = 0;                    //If we at any point didn't stay within the counter, we reset the counter
        }
    }
    else {
        if((error*error)>=1){                           //After reaching and holding our setpoint we check if we slip...
            errorHandlerTracker++;
            
            if(errorHandlerTracker > ERROR_LIMIT){      // .. more than ERROR_LIMIT times
                errorOccured = 1;                       //... and if we do, we report an error...
                stopTemp();                             // ... and stop regulation
            }
        }
        
        else {
            errorHandlerTracker = 0;                    //If we didn't reach ERROR_LIMIT errors in a row, reset the counter
        }
    }
    
    if((timeTracker < (TIME_LIMIT+1)) && (setPointReached != 1)){
        timeTracker++;   
    } 
    
    if((timeTracker > TIME_LIMIT) && (errorOccured != 1) && (setPointReached != 1)){ //after TIME_LIMIT * 5 sec, if setpoint hasn't been reached...                   
        errorOccured = 1;                    //... report an error...
        stopTemp();                          //... and stop regulation.
    }
}

/* The regulation routine */

CY_ISR(timer_isr){
    SlowTime_ReadStatusRegister();          //Clear the IRQ register
    regulate(setpoint - getTemp());
}


/* Initiates the timer, ISR, and PWM blocks */

void initTemp(){
    PID_ISR_StartEx(timer_isr);
    Heater_PWM_Init();
    SlowTime_Init();
}

/* Starts regulation */

void regTemp(float newSetPoint){
    
    if(newSetPoint != setpoint){       //Does the new setpoint happen to be the same as the old?
        setpoint = newSetPoint;       
        setPointReached = 0;
    }
    
    if(!isRunning){
        integral = 0;
        last_error = 0;
        isRunning = 1;
        Heater_PWM_Start();
        PID_ISR_Enable();
        SlowTime_Start();
    }
}

/* Toggles the isRunning flag and PWM regulation */

void pauseTemp(){
    
    if(!isRunning){
        setPointReached = 0;
        Heater_PWM_Start();
        PID_ISR_Enable();
        SlowTime_Start();
    }
    else {
        Heater_PWM_Stop();
        PID_ISR_Disable();
        SlowTime_Stop();
    }
    
    isRunning = ~isRunning;
}

/* Stops all regulation routines */

void stopTemp(){
    if(isRunning){
        PID_ISR_Stop();
        Heater_PWM_Stop();
        SlowTime_Stop();
    }
}

/* the PI(D) regulation */
/*
void regulate(float error){
    int pwm;
    float derivative;
    
	// Integral
	integral = integral + (error * UPDATE_INTERVAL);
    
    if(integral > 2000){
        integral = 2000;
    }
    
    if(integral < -2000){
        integral = -2000;
    }
    
    
    if(error < 0){
        pwm = 0;        // Turns of PWM for lowering temperature
    }
    else {
        // Derivative
        derivative = (error - last_error)/ UPDATE_INTERVAL;
	
	    pwm =((Kp * error) + (Ki * integral) + (Kd * derivative))/MAX_TEMP;
        
        // Ensures PWM stays within 0 - 100 %
    	if (pwm > 255){
            pwm = 255;
        }
    
	    if (pwm < 0){
	        pwm = 0;
        }
    }
    
    Heater_PWM_WriteCompare1(pwm);      // Set Duty-Cycle
    
    last_error = error;
    
    stabilityControl(error);
    
    if(DEBUG_MODE){
        char buffer[120];
        sprintf(buffer,"SP: %1.2f - Err: %1.2f - PWM: %i - SPR: %i - ErrTrack: %i - ErrOcc: %i - Time: %i\n\r",setpoint,error,pwm,setPointReached,errorHandlerTracker,errorOccured,timeTracker);
        UART_1_PutString(buffer);
    }
}
*/

void regulate(float error){
    int pwm;
    float derivative;
    
	// Integral
	integral = integral + (error * UPDATE_INTERVAL);
    
    if(integral >= 2000){
        integral = 2000;
    }
    
    if(integral <= -2000){
        integral = -2000;
    }
    
    
    // Derivative
    derivative = (error - last_error)/ UPDATE_INTERVAL;
	
    pwm = ((Kp * error) + (Ki * integral) + (Kd * derivative));
        
    // Ensures PWM stays within 0 - 100 %
  	if (pwm > 255){
        pwm = 255;
    }
    
    if (pwm < 0){
      pwm = 0;
    }
 
    
    Heater_PWM_WriteCompare1(pwm);      // Set Duty-Cycle
    
    last_error = error;
    
    stabilityControl(error);
}

/* [] END OF FILE */
