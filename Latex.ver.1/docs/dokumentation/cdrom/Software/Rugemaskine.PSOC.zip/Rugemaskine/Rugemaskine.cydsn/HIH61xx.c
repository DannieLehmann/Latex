/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// HIH6121-021 is a slave I2C

#include "HIH61xx.h"

#define Address 0x27 // HIH6121-021 have address available from 0X00 til 0x7F, default 0x27

// ***** Error - return values *****
/* Error values
I2C_HIH61xx_MSTR_NO_ERROR                0
I2C_HIH61xx_MSTR_BUS_BUSY                1 
I2C_HIH61xx_MSTR_NOT_READY               2
I2C_HIH61xx_MSTR_ERR_LB_NAK              3
I2C_HIH61xx_MSTR_ERR_ARB_LOST            4
I2C_HIH61xx_MSTR_ERR_ABORT_START_GEN     5
*/

// ***** Values *****
static uint8 err = I2C_HIH61xx_MSTR_NO_ERROR, i = 0, status = 0;
uint8 buf[4] = {0,0,0,0};
static float temperature = 0, humidty = 0;
static uint16 temp = 0;

void Init_HIH61xx(void)
{
    I2C_HIH61xx_Start();
}

uint8 Read_HIH61xx(void)
{
    static float temperature_ = 0, humidty_ = 0;
    err = I2C_HIH61xx_MasterSendStart(Address,1); // Read
    for(i = 0; i < 4; i++)
    {
        if(err == I2C_HIH61xx_MSTR_NO_ERROR && i < 3)
            buf[i] = I2C_HIH61xx_MasterReadByte(I2C_HIH61xx_ACK_DATA ); //Address, &buf[i], 8,I2C_HIH61xx_MODE_NO_STOP
        if(err == I2C_HIH61xx_MSTR_NO_ERROR && i == 3)
            buf[i] = I2C_HIH61xx_MasterReadByte(I2C_HIH61xx_NAK_DATA ); //Address, &buf[i], 8,I2C_HIH61xx_MODE_NO_STOP

    }
    if(err == I2C_HIH61xx_MSTR_NO_ERROR)
    err = I2C_HIH61xx_MasterSendStop(); //Send Stop
    
    
    status = (6 >> (buf[0]) );
    
    buf[0] = buf[0] & 0x3f;
    temp = buf[0] & 0xffff;
    temp = (temp<<8) | buf[1];
    humidty_ = temp + 0;
    humidty = (humidty_/16382)*100; // Value/(2^14-2)*100%
    
    temp = buf[2] & 0xffff;
    temp = (((temp<<8) | buf[3]) >> 2);
    temperature_ = temp + 0;
    temperature = ((temperature_/16382)*165)-40;

    return err;
}
uint8 Measure_HIH61xx(void)
{
    //sendCmd = sendCmd && 0b11111110; // last bit indekt til measure to measure
    
    do
    {
        err = I2C_HIH61xx_MasterSendStart(Address,0); // Read
        err = I2C_HIH61xx_MasterSendStop(); //Send Stop
        CyDelayUs(500);
    }
    while(err != I2C_HIH61xx_MSTR_NO_ERROR);
    return err;
}

float getTemp(void)
{
    return temperature;
}

float getHumid(void)
{
    return humidty;
}

void reset_HIH61xx(void)
{
    I2C_HIH61xx_Stop();
    I2C_HIH61xx_Start();    
}
/* [] END OF FILE */
