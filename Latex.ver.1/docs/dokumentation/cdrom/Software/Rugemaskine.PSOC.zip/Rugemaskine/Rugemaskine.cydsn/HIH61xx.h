/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef HIH61XX_H
#define HIH61XX_H
#include <project.h>
#include <math.h>
    
void Init_HIH61xx(void);
void reset_HIH61xx(void);
uint8 Read_HIH61xx(void);
uint8 Measure_HIH61xx(void);
float getTemp(void);
float getHumid(void);
#endif
/* [] END OF FILE */
