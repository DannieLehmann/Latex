/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#include <project.h>
#include <stdio.h>
#include "befugter.h"
#include "HIH61xx.h"

#define SUCCESS_LIMIT 6
#define ERROR_LIMIT 1
#define TIME_LIMIT 12 //120 //120*5 Sec = 10 minutter

#define DEBUG_MODE 1

static float setpoint = 0.0;

static short int errorHandlerTracker = 0,   //Keeps track of recurring successes
            setPointReached = 0,            //Flag for 12 successes in a row
            errorOccured = 0,               //Flag for if error occurred
            timeTracker = 0,                //For timing
            isRunning = 0;


/* For detecting errors; 
 * Will keep track of when the temperature reaches a steady state, within +/- 1 degree of the setpoint
 * for a period of one minute; when this happens, a flag will be set. If the tenperature falls outside this 
 * range more than N times in a row, an error flag is made.
 */

void stabilityControl_h(float error){
    
    if(setPointReached==0){                            //Until the setpoint is reached...
        if((error*error)<=100){                          //If the error numerically is less than 10, add one to the counter
            errorHandlerTracker++;
    
            if(errorHandlerTracker > SUCCESS_LIMIT){   //If we 12 times in a row (a 60 second duration) succesfully stayed within 1 degree, we're have succesfully reached our setpoint
                setPointReached = 1;
                errorHandlerTracker = 0;
                timeTracker = 0;
            }
        }
        
        else {
            errorHandlerTracker = 0;                    //If we at any point didn't stay within the counter, we reset the counter
        }
    }
    else {
        if((error*error)>=100){                           //After reaching and holding our setpoint we check if we slip...
            errorHandlerTracker++;
            
            if(errorHandlerTracker > ERROR_LIMIT){      // .. more than ERROR_LIMIT times
                errorOccured = 1;                       //... and if we do, we report an error...
                stopHum();                             // ... and stop regulation
            }
        }
        
        else {
            errorHandlerTracker = 0;                    //If we didn't reach ERROR_LIMIT errors in a row, reset the counter
        }
    }
    
    if((timeTracker < (TIME_LIMIT+1)) && (setPointReached != 1)){
        timeTracker++;   
    } 
    
    if((timeTracker > TIME_LIMIT) && (errorOccured != 1) && (setPointReached != 1)){ //after TIME_LIMIT * 5 sec, if setpoint hasn't been reached...                   
        errorOccured = 1;                    //... report an error...
        stopHum();                          //... and stop regulation.
 
    }
}

/* The regulation routine */

CY_ISR(humid_isr){
    float currentHumid;
    
    currentHumid = getHumid();              //Acquire current humidty level

    Humidity_timer_ReadStatusRegister();          //Clear the IRQ register
    
    if(currentHumid < (setpoint-10)){
        Humidity_out_Write(1);
        Humidity_out_Write(0);
    }
    stabilityControl_h(setpoint - currentHumid);
}


/* Initiates the timer, ISR, and PWM blocks */

void initHum(){
    Humidity_ISR_StartEx(humid_isr);
    Humidity_timer_Init();
}

/* Starts regulation */

void regHum(float newSetPoint){
    
    if(newSetPoint != setpoint){       //Does the new setpoint happen to be the same as the old?
        setpoint = newSetPoint;       
        setPointReached = 0;
    }
    
    if(!isRunning){
        isRunning = 1;
        Humidity_timer_Start();
    }
}

/* Toggles the isRunning flag and PWM regulation */

void pauseHum(){
    
    if(!isRunning){
        Humidity_timer_Start();
    }
    else {
        Humidity_timer_Stop();
    }
    
    isRunning = ~isRunning;
}

/* Stops all regulation routines */

void stopHum(){
    if(isRunning){
        Humidity_timer_Stop();
    }
}

/* [] END OF FILE */
