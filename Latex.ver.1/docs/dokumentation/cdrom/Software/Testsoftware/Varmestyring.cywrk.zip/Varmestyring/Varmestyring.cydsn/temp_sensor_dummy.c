/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "temp_sensor_dummy.h"

float temperature = 15.0;
int whenToErrCounter = 0;

float getTemp(){
    
    whenToErrCounter++;
    
    if(whenToErrCounter < 16){
        float temp = temperature;
        temperature += (37-temperature)/2;
        
        return temp;
    }
    else {
        return temperature -= 0.5;
    }
}

int* counter(){
    return &whenToErrCounter;
}
/* [] END OF FILE */
