/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include "temperature.h"
#include "temp_sensor_dummy.h"
int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    initTemp();
    UART_1_Start();
    
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    regTemp(37.0);
   
    while(*counter() < 16);
    regTemp(34.0);
    while(1);
    
}

/* [] END OF FILE */
