/*******************************************************************************
* File Name: MotorISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_ISR_MotorISR_H)
#define CY_ISR_MotorISR_H

#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void MotorISR_Start(void) ;
void MotorISR_StartEx(cyisraddress address) ;
void MotorISR_Stop(void) ;

CY_ISR_PROTO(MotorISR_Interrupt);

void MotorISR_SetVector(cyisraddress address) ;
cyisraddress MotorISR_GetVector(void) ;

void MotorISR_SetPriority(uint8 priority) ;
uint8 MotorISR_GetPriority(void) ;

void MotorISR_Enable(void) ;
uint8 MotorISR_GetState(void) ;
void MotorISR_Disable(void) ;

void MotorISR_SetPending(void) ;
void MotorISR_ClearPending(void) ;


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the MotorISR ISR. */
#define MotorISR_INTC_VECTOR            ((reg16 *) MotorISR__INTC_VECT)

/* Address of the MotorISR ISR priority. */
#define MotorISR_INTC_PRIOR             ((reg8 *) MotorISR__INTC_PRIOR_REG)

/* Priority of the MotorISR interrupt. */
#define MotorISR_INTC_PRIOR_NUMBER      MotorISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable MotorISR interrupt. */
#define MotorISR_INTC_SET_EN            ((reg8 *) MotorISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the MotorISR interrupt. */
#define MotorISR_INTC_CLR_EN            ((reg8 *) MotorISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the MotorISR interrupt state to pending. */
#define MotorISR_INTC_SET_PD            ((reg8 *) MotorISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the MotorISR interrupt. */
#define MotorISR_INTC_CLR_PD            ((reg8 *) MotorISR__INTC_CLR_PD_REG)



#endif /* CY_ISR_MotorISR_H */


/* [] END OF FILE */
