/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

void StepMotor_Init(void);
/*
*   StepMotor_Init functionality:
*   Starting the MotorTimer
*/

void StepMotor_Rotate(void);
/*
*   StepMotor_Rotate functionality:
*   Enabling the MotorISR
*/

/* [] END OF FILE */
