/*******************************************************************************
* File Name: Humidity_out.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Humidity_out_H) /* Pins Humidity_out_H */
#define CY_PINS_Humidity_out_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Humidity_out_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Humidity_out_Write(uint8 value) ;
void    Humidity_out_SetDriveMode(uint8 mode) ;
uint8   Humidity_out_ReadDataReg(void) ;
uint8   Humidity_out_Read(void) ;
uint8   Humidity_out_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Humidity_out_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Humidity_out_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Humidity_out_DM_RES_UP          PIN_DM_RES_UP
#define Humidity_out_DM_RES_DWN         PIN_DM_RES_DWN
#define Humidity_out_DM_OD_LO           PIN_DM_OD_LO
#define Humidity_out_DM_OD_HI           PIN_DM_OD_HI
#define Humidity_out_DM_STRONG          PIN_DM_STRONG
#define Humidity_out_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Humidity_out_MASK               Humidity_out__MASK
#define Humidity_out_SHIFT              Humidity_out__SHIFT
#define Humidity_out_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Humidity_out_PS                     (* (reg8 *) Humidity_out__PS)
/* Data Register */
#define Humidity_out_DR                     (* (reg8 *) Humidity_out__DR)
/* Port Number */
#define Humidity_out_PRT_NUM                (* (reg8 *) Humidity_out__PRT) 
/* Connect to Analog Globals */                                                  
#define Humidity_out_AG                     (* (reg8 *) Humidity_out__AG)                       
/* Analog MUX bux enable */
#define Humidity_out_AMUX                   (* (reg8 *) Humidity_out__AMUX) 
/* Bidirectional Enable */                                                        
#define Humidity_out_BIE                    (* (reg8 *) Humidity_out__BIE)
/* Bit-mask for Aliased Register Access */
#define Humidity_out_BIT_MASK               (* (reg8 *) Humidity_out__BIT_MASK)
/* Bypass Enable */
#define Humidity_out_BYP                    (* (reg8 *) Humidity_out__BYP)
/* Port wide control signals */                                                   
#define Humidity_out_CTL                    (* (reg8 *) Humidity_out__CTL)
/* Drive Modes */
#define Humidity_out_DM0                    (* (reg8 *) Humidity_out__DM0) 
#define Humidity_out_DM1                    (* (reg8 *) Humidity_out__DM1)
#define Humidity_out_DM2                    (* (reg8 *) Humidity_out__DM2) 
/* Input Buffer Disable Override */
#define Humidity_out_INP_DIS                (* (reg8 *) Humidity_out__INP_DIS)
/* LCD Common or Segment Drive */
#define Humidity_out_LCD_COM_SEG            (* (reg8 *) Humidity_out__LCD_COM_SEG)
/* Enable Segment LCD */
#define Humidity_out_LCD_EN                 (* (reg8 *) Humidity_out__LCD_EN)
/* Slew Rate Control */
#define Humidity_out_SLW                    (* (reg8 *) Humidity_out__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Humidity_out_PRTDSI__CAPS_SEL       (* (reg8 *) Humidity_out__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Humidity_out_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Humidity_out__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Humidity_out_PRTDSI__OE_SEL0        (* (reg8 *) Humidity_out__PRTDSI__OE_SEL0) 
#define Humidity_out_PRTDSI__OE_SEL1        (* (reg8 *) Humidity_out__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Humidity_out_PRTDSI__OUT_SEL0       (* (reg8 *) Humidity_out__PRTDSI__OUT_SEL0) 
#define Humidity_out_PRTDSI__OUT_SEL1       (* (reg8 *) Humidity_out__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Humidity_out_PRTDSI__SYNC_OUT       (* (reg8 *) Humidity_out__PRTDSI__SYNC_OUT) 


#if defined(Humidity_out__INTSTAT)  /* Interrupt Registers */

    #define Humidity_out_INTSTAT                (* (reg8 *) Humidity_out__INTSTAT)
    #define Humidity_out_SNAP                   (* (reg8 *) Humidity_out__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Humidity_out_H */


/* [] END OF FILE */
