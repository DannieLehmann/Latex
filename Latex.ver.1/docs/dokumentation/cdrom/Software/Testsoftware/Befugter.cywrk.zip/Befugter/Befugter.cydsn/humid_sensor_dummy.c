/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

static int step = 0;

float getHumid(){
    if(step == 0){
        step++;
        return 50.0;                //Initial humidity, provokes splash
    }
    if((step > 0) && (step < 6)){
        step++;
        return 70.0;                //triggers nothing
    }
    if(step == 6){
        step++;
        return 61.0;                //should trigger splash, no error detecton
    }
    if((step > 6) && (step < 10)){
        step++;
        return 70.0;                //triggers nothing
    }
    else {
        return 50.0;                //should trigger one splash, then err
    }
}
/* [] END OF FILE */
