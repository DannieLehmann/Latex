/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include "befugter.h"
#include "humid_sensor_dummy.h"

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    initHum();
    UART_Start();
    
    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
    
    regHum(70.0);
    
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
