/* ========================================
 *
 * Copyright AU, 2014
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF AU.
 *
 * ========================================
*/

/* Defines */
#define CHICK_TEMP_NORMAL    37.0f //degrees
#define CHICK_TEMP_LOW       20.0f //degrees
#define CHICK_HUM_NORMAL     45.0f //percent
#define CHICK_HUM_HIGH       75.0f //percent

#include <project.h>

/* TEST */
#include <stdio.h>

/* Global Variables */
uint16 countInMinutes;
uint16 timeStamp;
uint8 hatchOpen;
uint8 countFlag;
uint8 sensorFlag;
uint8 henFlag; // indicates it's time for daily clearing of the air

uint8 test1 = 0;

char8 string[80]; // test

/* Function Prototypes */
CY_ISR_PROTO(isr_timer_sequence);
CY_ISR_PROTO(isr_spi_rx);

int main()
{
    /* Initialize global variables */
    countInMinutes = 0u;
    timeStamp = 0u;
    hatchOpen = 0u;
    countFlag = 0u;
    sensorFlag = 0u;
    henFlag = 0u;
    
	/* Enable global interrupts. */
    CyGlobalIntEnable; 

    /* Init SPI Slave */
    SPIS_1_Start();
	SPIS_1_EnableRxInt();
	rx_isr_StartEx(isr_spi_rx);
	SPIS_1_ClearFIFO();
	SPIS_1_ClearTxBuffer();
    
    /* Enable the Interrupt component connected to Timer interrupt */
    TimerISR_StartEx(isr_timer_sequence);
    
    /* Enabling the UART */
    UART_1_Start(); 

	for(;;)
    {
		/* MAIN SEQUENCE LOOP */
        
        // if timer-interrupt has occurrred (1 minut has passed)
        if (countFlag == 1)
        {
            countFlag = 0;
            countInMinutes++;      
            
            if (hatchOpen == 0)
            {
                // if 12 hours have passed (rotate egg)
                if ((countInMinutes % 720) == 0)
                {
                    //rotate();    
                    
                    sprintf(string, "Rotate. Count == %d\n\r", countInMinutes);
    	            UART_1_PutString(string);
                }
                
                // if 24 hours have passed (vent the environment)
                if ((countInMinutes % 1440) == 0)
                {
                    //regTemp(CHICK_TEMP_LOW);
                    
                    henFlag = 1; 
                    timeStamp = countInMinutes;
                    
                    sprintf(string, "Udluftning. Count == %d\n\r", countInMinutes);
    	            UART_1_PutString(string);
                }
                
                // if 30 minutes have passed since venting the environment (return to normal)
                if (henFlag == 1 && (countInMinutes - timeStamp) == 30)
                {
                    henFlag = 0;
                    //regTemp(CHICK_TEMP_NORMAL);
                    
                    sprintf(string, "Udluftning slut. Count == %d\n\r", countInMinutes);
    	            UART_1_PutString(string);
                }
                
                // if 18 days have passed (increase humidity)
                if ((countInMinutes % 25920) == 0)
                {
                    //regHum(CHICK_HUM_HIGH);    
                    
                    sprintf(string, "18 dage. Count == %d\n\r", countInMinutes);
    	            UART_1_PutString(string);
                }
                
                // if 21 days have passed (stop sequence)
                if ((countInMinutes % 30240) == 0)
                {
                    Timer_1_Stop();
                    
                    sprintf(string, "21 dage. Count == %d\n\r", countInMinutes);
    	            UART_1_PutString(string);
                }
            }
        }
	}
    return 0;
}

/*
 * Timer ISR
 * Interrupts every minut and sets countFlag
 */
CY_ISR(isr_timer_sequence) 
{
	/* Read Status register in order to clear the sticky Terminal Count (TC) bit 
	 * in the status register. Note that the function is not called, but rather 
	 * the status is read directly.
	 */
   	Timer_1_STATUS;
    
	/* Set flag to indicate interrupt received */
    countFlag = 1;
}


/*
 * SPI RX ISR
 * Decodes SPI RX data and perform tasks accordingly.
 */
CY_ISR(isr_spi_rx) {

	uint16 rxvalue;
    uint8 addr;
	uint8 cmd;
	uint8 rddata;

	rxvalue = SPIS_1_ReadRxData(); 

	addr = (rxvalue >> 12) & 0xf;   // cmd = rdvalue[15:12]
	cmd = (rxvalue >> 8) & 0xf;     // addr = rdvalue[11:8]
	rddata = rxvalue & 0xff;        // data = rdvalue[7:0]
    
    // See documentation for protocol specifics.

	switch (addr) {
		case 0x1: //start or stop sequence
			if (cmd == 0x1) //command start
            {
                 Timer_1_Start();
                //countInMinutes = 0u;
               //regTemp(CHICK_TEMP_NORMAL);
              //regHum(CHICK_HUM_NORMAL);                
               
            }
                
            else if (cmd == 0x2) //command stop
            {
                //stopTemp();
                //stopHum();
                Timer_1_Stop();
            }
            break;
		case 0x2: //status temperature
			if (cmd == 0x3) //command status
            {   
                SPIS_1_ClearTxBuffer();
				//SPIS_1_WriteTxData((uint16)getTemp());
                SPIS_1_WriteTxData(25);
                
//                if (sensorFlag == 0)
//                {
//                    sensorFlag = 1;
//                    Measure_HIH61xx(); 
//                }
//                else
//                {
//                    sensorFlag = 0;
//                    Read_HIH61xx();
//                }
            }
			break;
		case 0x3: //status humidity
			if (cmd == 0x3) //command status
            {
				SPIS_1_ClearTxBuffer();
				//SPIS_1_WriteTxData((uint16)getHumid());
                SPIS_1_WriteTxData(45);
            }
			break;
		case 0x4: //status time
			if (cmd == 0x3) //command status
            {
				SPIS_1_ClearTxBuffer();
				SPIS_1_WriteTxData(countInMinutes);
            }
		default:
			break;
	}
}
/* [] END OF FILE */
