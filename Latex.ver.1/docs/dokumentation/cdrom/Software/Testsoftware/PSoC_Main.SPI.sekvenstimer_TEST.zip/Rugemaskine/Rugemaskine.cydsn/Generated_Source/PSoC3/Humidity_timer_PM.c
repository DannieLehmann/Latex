/*******************************************************************************
* File Name: Humidity_timer_PM.c
* Version 2.50
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Humidity_timer.h"
static Humidity_timer_backupStruct Humidity_timer_backup;


/*******************************************************************************
* Function Name: Humidity_timer_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Humidity_timer_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Humidity_timer_SaveConfig(void) 
{
    #if (!Humidity_timer_UsingFixedFunction)
        /* Backup the UDB non-rentention registers for CY_UDB_V0 */
        #if (CY_UDB_V0)
            Humidity_timer_backup.TimerUdb = Humidity_timer_ReadCounter();
            Humidity_timer_backup.TimerPeriod = Humidity_timer_ReadPeriod();
            Humidity_timer_backup.InterruptMaskValue = Humidity_timer_STATUS_MASK;
            #if (Humidity_timer_UsingHWCaptureCounter)
                Humidity_timer_backup.TimerCaptureCounter = Humidity_timer_ReadCaptureCount();
            #endif /* Backup the UDB non-rentention register capture counter for CY_UDB_V0 */
        #endif /* Backup the UDB non-rentention registers for CY_UDB_V0 */

        #if (CY_UDB_V1)
            Humidity_timer_backup.TimerUdb = Humidity_timer_ReadCounter();
            Humidity_timer_backup.InterruptMaskValue = Humidity_timer_STATUS_MASK;
            #if (Humidity_timer_UsingHWCaptureCounter)
                Humidity_timer_backup.TimerCaptureCounter = Humidity_timer_ReadCaptureCount();
            #endif /* Back Up capture counter register  */
        #endif /* Backup non retention registers, interrupt mask and capture counter for CY_UDB_V1 */

        #if(!Humidity_timer_ControlRegRemoved)
            Humidity_timer_backup.TimerControlRegister = Humidity_timer_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Humidity_timer_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Humidity_timer_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Humidity_timer_RestoreConfig(void) 
{   
    #if (!Humidity_timer_UsingFixedFunction)
        /* Restore the UDB non-rentention registers for CY_UDB_V0 */
        #if (CY_UDB_V0)
            /* Interrupt State Backup for Critical Region*/
            uint8 Humidity_timer_interruptState;

            Humidity_timer_WriteCounter(Humidity_timer_backup.TimerUdb);
            Humidity_timer_WritePeriod(Humidity_timer_backup.TimerPeriod);
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            Humidity_timer_interruptState = CyEnterCriticalSection();
            /* Use the interrupt output of the status register for IRQ output */
            Humidity_timer_STATUS_AUX_CTRL |= Humidity_timer_STATUS_ACTL_INT_EN_MASK;
            /* Exit Critical Region*/
            CyExitCriticalSection(Humidity_timer_interruptState);
            Humidity_timer_STATUS_MASK =Humidity_timer_backup.InterruptMaskValue;
            #if (Humidity_timer_UsingHWCaptureCounter)
                Humidity_timer_SetCaptureCount(Humidity_timer_backup.TimerCaptureCounter);
            #endif /* Restore the UDB non-rentention register capture counter for CY_UDB_V0 */
        #endif /* Restore the UDB non-rentention registers for CY_UDB_V0 */

        #if (CY_UDB_V1)
            Humidity_timer_WriteCounter(Humidity_timer_backup.TimerUdb);
            Humidity_timer_STATUS_MASK =Humidity_timer_backup.InterruptMaskValue;
            #if (Humidity_timer_UsingHWCaptureCounter)
                Humidity_timer_SetCaptureCount(Humidity_timer_backup.TimerCaptureCounter);
            #endif /* Restore Capture counter register*/
        #endif /* Restore up non retention registers, interrupt mask and capture counter for CY_UDB_V1 */

        #if(!Humidity_timer_ControlRegRemoved)
            Humidity_timer_WriteControlRegister(Humidity_timer_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Humidity_timer_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Humidity_timer_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Humidity_timer_Sleep(void) 
{
    #if(!Humidity_timer_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Humidity_timer_CTRL_ENABLE == (Humidity_timer_CONTROL & Humidity_timer_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Humidity_timer_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Humidity_timer_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Humidity_timer_Stop();
    Humidity_timer_SaveConfig();
}


/*******************************************************************************
* Function Name: Humidity_timer_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Humidity_timer_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Humidity_timer_Wakeup(void) 
{
    Humidity_timer_RestoreConfig();
    #if(!Humidity_timer_ControlRegRemoved)
        if(Humidity_timer_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Humidity_timer_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
